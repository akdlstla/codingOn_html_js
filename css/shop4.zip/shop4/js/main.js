// alert("testing");
$(function(){
    $('.navbar_toggleBtn').click(function(){
        $('.navbar_menu').toggle("active");
    })

    $(window).resize(function(){
        //nav의 너비값이 문자이므로 숫자로 형변환함
        if(parseInt($('nav').css('width')) > 768){
            $('.navbar_menu').css('display', 'flex');
        }
    })
})